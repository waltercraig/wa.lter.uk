# WebApp

A nice website starter pack that makes use of webpack and babel with some basic boilerplate sass

### Version

1.0.0

## Usage

npm install

npm run build

npm start
