export const user = {
  name: "Jon Doe",
  Occupation: "Ninja"
};
